# Multi-Stage Docker Containerization & Optimization

A small production-oriented Node.js + PostgreSQL full-stack service created for Task 03.

## Deliverables

- Multi-stage `Dockerfile`
- Non-root runtime user
- `docker-compose.yml` for web + PostgreSQL
- Application and database health checks
- Named PostgreSQL volume for persistence
- Reproducible npm dependency install
- `.dockerignore`
- Build/test log template in `BUILD_LOG.md`

## Architecture

```text
Client
  |
  v
Node.js / Express container :3000
  |
  v
PostgreSQL 16 container
  |
  v
Named volume: postgres_data
```

## Run

```bash
docker compose up --build -d
docker compose ps
curl http://localhost:3000/health
```

Create data:

```bash
curl -X POST http://localhost:3000/api/items \
  -H "Content-Type: application/json" \
  -d '{"name":"hello from Docker"}'

curl http://localhost:3000/api/items
```

Test persistence:

```bash
docker compose restart db
curl http://localhost:3000/api/items
```

## Verify non-root execution

```bash
docker compose exec web id
```

The runtime should report `appuser` rather than `root`.

## Verify the final image size

```bash
docker image inspect task03-web:latest \
  --format '{{.Size}} bytes'
```

Target: less than 150 MB. The final image uses Alpine Linux, production-only dependencies, a dedicated runtime stage, and excludes development/build artifacts.

## Security/optimization choices

1. Multi-stage build keeps build/development artifacts out of the runtime image.
2. Alpine runtime minimizes the base footprint.
3. `npm ci --omit=dev` installs production dependencies only.
4. `.dockerignore` prevents local dependencies, VCS metadata and development files entering the build context.
5. The application runs as an unprivileged `appuser`.
6. The database password is supplied through Compose environment configuration for the exercise; production should use Docker/Kubernetes secrets or a managed secret store.
7. Health checks distinguish application readiness from process liveness.
8. PostgreSQL data is stored in a named volume so container recreation does not delete application data.

## Production note

For a real deployment, pin image digests, use a secret manager, run vulnerability scanning, add resource limits, and use TLS/reverse proxying at the edge.

# Capstone Evidence Checklist

Do not claim these checks are complete until they have been run on the deployed AWS instance.

## AWS / application

- [ ] Terraform `apply` completed successfully
- [ ] EC2 public IP recorded
- [ ] Application URL responds successfully
- [ ] `/health` returns healthy
- [ ] `/metrics` returns Prometheus metrics

## Monitoring

- [ ] Prometheus target `capstone-app` is UP
- [ ] Node Exporter target is UP
- [ ] Grafana dashboard loads
- [ ] App-down alert is visible/configured
- [ ] 5xx alert is visible/configured
- [ ] p95 latency alert is visible/configured

## CI/CD

- [ ] GitHub Actions test job green
- [ ] Compose validation green
- [ ] Terraform validation green
- [ ] Docker build green

## Final submission

Public GitHub repository:
`PASTE_PUBLIC_GITHUB_URL`

Live application:
`PASTE_LIVE_APPLICATION_URL`

Grafana:
`PASTE_GRAFANA_URL`

AWS public IP:
`PASTE_PUBLIC_IP`

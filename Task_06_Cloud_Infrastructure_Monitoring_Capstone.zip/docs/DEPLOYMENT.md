# End-to-End Deployment Guide

## Local smoke test

```bash
docker compose up -d --build
docker compose ps
./scripts/verify.sh
```

Expected:
- app healthy
- Nginx returns the application
- Prometheus can scrape the app
- Grafana is reachable under `/grafana/`

## AWS

1. Push this repository to GitHub and make it public.
2. Install/configure AWS CLI.
3. Create/select an EC2 key pair.
4. Copy Terraform variables:

```bash
cp terraform/terraform.tfvars.example terraform/terraform.tfvars
```

5. Set `ssh_cidr_blocks` to your public IP/32.
6. Set `repo_url` to the public GitHub repository.
7. Deploy:

```bash
terraform -chdir=terraform init
terraform -chdir=terraform plan
terraform -chdir=terraform apply
```

8. Wait for the instance bootstrap to complete.
9. Use the Terraform `application_url` output.
10. Open the `grafana_url` output.

## Environment variables

`GRAFANA_ADMIN_USER` and `GRAFANA_ADMIN_PASSWORD` can be set in the deployment environment before `docker compose up`.

For production, do not commit passwords to Git. Prefer AWS Secrets Manager or SSM Parameter Store.

## Teardown

```bash
terraform -chdir=terraform destroy
```

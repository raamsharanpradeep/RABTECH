# Cloud Infrastructure Deployment & Monitoring Capstone

This repository is a complete, reproducible capstone for deploying a containerized web application to **AWS EC2** with **Docker Compose**, **Prometheus**, and **Grafana**.

## Architecture

```text
Internet
   |
   v
AWS EC2
   |
   +--> Nginx :80/:443
          |
          +--> Node.js app :3000
          |      |
          |      +--> /health
          |      +--> /metrics
          |
          +--> Grafana :3000 (published through /grafana/)
                 |
                 +--> Prometheus :9090
                        |
                        +--> Node Exporter :9100
```

The application exposes Prometheus metrics for request count and latency. Prometheus evaluates uptime, error-rate, and p95-latency alert rules. Grafana is provisioned automatically with a Prometheus datasource and dashboard.

## Repository structure

- `app/` — Node.js application + production Dockerfile
- `docker-compose.yml` — application, Nginx, Prometheus, Grafana, Node Exporter
- `nginx/` — reverse proxy
- `monitoring/prometheus/` — scrape config and alert rules
- `monitoring/grafana/` — datasource and dashboard provisioning
- `terraform/` — AWS EC2 + security group + bootstrap configuration
- `.github/workflows/deploy.yml` — CI validation/build workflow
- `scripts/verify.sh` — smoke checks
- `docs/DEPLOYMENT.md` — end-to-end deployment
- `docs/EVIDENCE.md` — required mentor evidence

## Deploy to AWS

Prerequisites:
- AWS account
- AWS CLI credentials configured locally
- Existing EC2 key pair
- Public GitHub repository containing this project
- Terraform >= 1.6

1. Copy `terraform/terraform.tfvars.example` to `terraform/terraform.tfvars`.
2. Set your EC2 key pair name, your public IP `/32`, and this repository URL.
3. Run:

```bash
terraform -chdir=terraform init
terraform -chdir=terraform plan
terraform -chdir=terraform apply
```

Terraform outputs:
- `application_url`
- `grafana_url`
- `public_ip`
- `ssh_command`

The EC2 user-data script installs Docker, clones the repository and starts the stack.

## Monitoring

Prometheus:
- App scrape target: `app:3000/metrics`
- Node Exporter: `node-exporter:9100`
- App-down alert after 2 minutes
- 5xx alert above 5% for 5 minutes
- p95 latency alert above 500 ms for 10 minutes

Grafana:
- Open `/grafana/` on the EC2 host.
- Default credentials are configurable through `GRAFANA_ADMIN_USER` and `GRAFANA_ADMIN_PASSWORD`.
- Change the default password before exposing Grafana publicly.

## Health checks

```bash
curl http://YOUR_PUBLIC_IP/health
curl http://YOUR_PUBLIC_IP/metrics
```

## CI

GitHub Actions runs:
1. Node.js tests
2. Docker Compose configuration validation
3. Terraform formatting/validation
4. Docker image build

## Cost and security notes

The default instance is `t3.small` in `ap-south-1`; change it to match your budget and AWS availability. Restrict SSH to your own public IP instead of `0.0.0.0/0`.

For production:
- terminate TLS on Nginx and use a real certificate
- store secrets in AWS Secrets Manager/SSM Parameter Store
- use an IAM role instead of long-lived AWS credentials
- pin container images by digest
- use EBS encryption and backups
- put the service behind an ALB/WAF when appropriate
- avoid exposing Prometheus directly to the Internet
- use persistent/remote monitoring storage for long retention

output "ssh_command" {
  value = "ssh -i <key.pem> ubuntu@${aws_instance.capstone.public_ip}"
}

variable "aws_region" {
  type    = string
  default = "ap-south-1"
}

variable "instance_type" {
  type    = string
  default = "t3.small"
}

variable "key_name" {
  type        = string
  description = "Existing EC2 key-pair name."
}

variable "ssh_cidr_blocks" {
  type        = list(string)
  description = "Trusted public CIDRs allowed to SSH. Replace 0.0.0.0/0 with your own IP/32."
  default     = ["0.0.0.0/0"]
}

variable "repo_url" {
  type        = string
  description = "Public GitHub repository URL containing this project."
}

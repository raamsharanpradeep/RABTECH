#!/usr/bin/env bash
set -euo pipefail

echo "== Compose services =="
docker compose ps

echo "== App health =="
curl -fsS http://localhost/health
echo

echo "== Metrics endpoint =="
curl -fsS http://localhost/metrics | head -n 20
echo

echo "== Prometheus =="
curl -fsS http://localhost:9090/-/ready 2>/dev/null || true

echo "== Grafana =="
curl -fsSI http://localhost/grafana/ | head -n 5 || true

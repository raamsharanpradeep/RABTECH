import express from "express";
import client from "prom-client";

const app = express();
const port = Number(process.env.PORT || 3000);

client.collectDefaultMetrics({ prefix: "capstone_" });

const requestCounter = new client.Counter({
  name: "http_requests_total",
  help: "Total HTTP requests",
  labelNames: ["method", "route", "status"]
});

const requestDuration = new client.Histogram({
  name: "http_request_duration_seconds",
  help: "HTTP request duration in seconds",
  labelNames: ["method", "route", "status"],
  buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2, 5]
});

app.use((req, res, next) => {
  const start = process.hrtime.bigint();
  res.on("finish", () => {
    const seconds = Number(process.hrtime.bigint() - start) / 1e9;
    const route = req.route?.path || req.path;
    requestCounter.inc({ method: req.method, route, status: res.statusCode });
    requestDuration.observe({ method: req.method, route, status: res.statusCode }, seconds);
  });
  next();
});

app.get("/", (_req, res) => {
  res.json({
    service: "cloud-capstone-app",
    status: "ok",
    version: process.env.APP_VERSION || "1.0.0"
  });
});

app.get("/health", (_req, res) => {
  res.status(200).json({ status: "healthy" });
});

app.get("/ready", (_req, res) => {
  res.status(200).json({ status: "ready" });
});

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", client.register.contentType);
  res.end(await client.register.metrics());
});

app.listen(port, "0.0.0.0", () => {
  console.log(`capstone app listening on ${port}`);
});

import test from "node:test";
import assert from "node:assert/strict";

test("health endpoint contract", () => {
  const response = { status: "healthy" };
  assert.equal(response.status, "healthy");
});

test("readiness endpoint contract", () => {
  const response = { status: "ready" };
  assert.equal(response.status, "ready");
});

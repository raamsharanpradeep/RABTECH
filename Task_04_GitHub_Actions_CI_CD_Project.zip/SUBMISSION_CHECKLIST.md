# Task 03 Submission Checklist

- [x] Multi-stage Dockerfile
- [x] Node.js web application
- [x] PostgreSQL service
- [x] Non-root application user
- [x] Application health check
- [x] Database health check
- [x] Named volume persistence
- [x] Production-only dependencies
- [x] .dockerignore
- [x] README with architecture and test commands
- [x] Build/test log template
- [ ] Run Docker build and paste actual build output into BUILD_LOG.md
- [ ] Record actual final image size and confirm <150 MiB
- [ ] Run health-check test
- [ ] Run persistence test
- [ ] Push repository to GitHub and make it public
- [ ] Submit the public GitHub URL

import express from "express";
import pg from "pg";

const { Pool } = pg;
const app = express();
app.use(express.json());

const PORT = Number(process.env.PORT || 3000);
const pool = new Pool({
  host: process.env.DB_HOST || "db",
  port: Number(process.env.DB_PORT || 5432),
  database: process.env.DB_NAME || "appdb",
  user: process.env.DB_USER || "appuser",
  password: process.env.DB_PASSWORD || "apppassword",
  max: 5
});

app.get("/", (_req, res) => {
  res.json({
    service: "task03-docker-webapp",
    status: "ok",
    message: "Multi-stage Docker container is running"
  });
});

app.get("/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.status(200).json({ status: "healthy", database: "ok" });
  } catch (error) {
    res.status(503).json({ status: "unhealthy", database: "unavailable" });
  }
});

app.get("/api/items", async (_req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, name, created_at FROM items ORDER BY id DESC LIMIT 50"
    );
    res.json(result.rows);
  } catch {
    res.status(500).json({ error: "database query failed" });
  }
});

app.post("/api/items", async (req, res) => {
  const name = String(req.body?.name || "").trim();
  if (!name || name.length > 100) {
    return res.status(400).json({ error: "name is required and must be <= 100 chars" });
  }
  try {
    const result = await pool.query(
      "INSERT INTO items (name) VALUES ($1) RETURNING id, name, created_at",
      [name]
    );
    res.status(201).json(result.rows[0]);
  } catch {
    res.status(500).json({ error: "database insert failed" });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`web listening on 0.0.0.0:${PORT}`);
});

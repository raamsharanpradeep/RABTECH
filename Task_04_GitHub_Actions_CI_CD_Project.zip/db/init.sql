CREATE TABLE IF NOT EXISTS items (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO items (name)
SELECT 'persistent sample item'
WHERE NOT EXISTS (SELECT 1 FROM items WHERE name = 'persistent sample item');

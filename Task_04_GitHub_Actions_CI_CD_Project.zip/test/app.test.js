import test from "node:test";
import assert from "node:assert/strict";

function validateName(value) {
  const name = String(value || "").trim();
  return Boolean(name && name.length <= 100);
}

test("accepts a normal item name", () => {
  assert.equal(validateName("hello"), true);
});

test("rejects an empty item name", () => {
  assert.equal(validateName(""), false);
});

test("rejects names longer than 100 characters", () => {
  assert.equal(validateName("x".repeat(101)), false);
});

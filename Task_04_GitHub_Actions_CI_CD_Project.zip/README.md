# Multi-Stage Docker Containerization & Optimization

[![CI/CD](https://github.com/OWNER/REPO/actions/workflows/ci-cd.yml/badge.svg)](https://github.com/OWNER/REPO/actions/workflows/ci-cd.yml)

A small production-oriented Node.js + PostgreSQL full-stack service created for Task 03.

## Deliverables

- Multi-stage `Dockerfile`
- Non-root runtime user
- `docker-compose.yml` for web + PostgreSQL
- Application and database health checks
- Named PostgreSQL volume for persistence
- Reproducible npm dependency install
- `.dockerignore`
- Build/test log template in `BUILD_LOG.md`

## Architecture

```text
Client
  |
  v
Node.js / Express container :3000
  |
  v
PostgreSQL 16 container
  |
  v
Named volume: postgres_data
```

## Run

```bash
docker compose up --build -d
docker compose ps
curl http://localhost:3000/health
```

Create data:

```bash
curl -X POST http://localhost:3000/api/items \
  -H "Content-Type: application/json" \
  -d '{"name":"hello from Docker"}'

curl http://localhost:3000/api/items
```

Test persistence:

```bash
docker compose restart db
curl http://localhost:3000/api/items
```

## Verify non-root execution

```bash
docker compose exec web id
```

The runtime should report `appuser` rather than `root`.

## Verify the final image size

```bash
docker image inspect task03-web:latest \
  --format '{{.Size}} bytes'
```

Target: less than 150 MB. The final image uses Alpine Linux, production-only dependencies, a dedicated runtime stage, and excludes development/build artifacts.

## Security/optimization choices

1. Multi-stage build keeps build/development artifacts out of the runtime image.
2. Alpine runtime minimizes the base footprint.
3. `npm ci --omit=dev` installs production dependencies only.
4. `.dockerignore` prevents local dependencies, VCS metadata and development files entering the build context.
5. The application runs as an unprivileged `appuser`.
6. The database password is supplied through Compose environment configuration for the exercise; production should use Docker/Kubernetes secrets or a managed secret store.
7. Health checks distinguish application readiness from process liveness.
8. PostgreSQL data is stored in a named volume so container recreation does not delete application data.

## Production note

For a real deployment, pin image digests, use a secret manager, run vulnerability scanning, add resource limits, and use TLS/reverse proxying at the edge.


## CI/CD

GitHub Actions is configured in `.github/workflows/ci-cd.yml`.

### Pull requests
- Installs dependencies with `npm ci`
- Runs ESLint
- Runs unit tests
- Does not publish an image

### Pushes to `main`
- Runs the same lint and unit-test gates
- Builds the multi-stage Docker image
- Publishes the image to GitHub Container Registry (GHCR)
- Tags the image as `latest` and with the commit SHA

The workflow uses the built-in `GITHUB_TOKEN` with `packages: write`; no long-lived Docker credentials are committed to the repository.

### Badge
After publishing the repository, replace `OWNER/REPO` in the badge above with the actual GitHub owner and repository name.

## Required GitHub settings
For GHCR publishing, ensure the repository Actions workflow has permission to write packages. The workflow requests `packages: write` and uses `${{ secrets.GITHUB_TOKEN }}`.

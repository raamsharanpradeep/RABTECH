# Container Build & Test Log

This file is a **run log template**. Replace the marked sections with the actual terminal output from the environment where Docker is executed. Do not claim a successful build unless the commands have actually been run.

## 1. Build

Command:

```bash
docker compose build --no-cache
```

Expected evidence:
- dependency stage completes
- runtime stage completes
- image tagged `task03-web:latest`

Actual output:
```text
PASTE ACTUAL BUILD OUTPUT HERE
```

## 2. Image size

Command:

```bash
docker image inspect task03-web:latest --format '{{.Size}}'
```

Actual result:
```text
PASTE ACTUAL IMAGE SIZE HERE
```

Acceptance criterion: `< 157286400` bytes (150 MiB).

## 3. Start services

```bash
docker compose up -d
docker compose ps
```

Expected: web and db are running/healthy.

Actual output:
```text
PASTE ACTUAL OUTPUT HERE
```

## 4. Health check

```bash
curl http://localhost:3000/health
```

Expected:

```json
{"status":"healthy","database":"ok"}
```

Actual output:
```text
PASTE ACTUAL OUTPUT HERE
```

## 5. Persistence test

```bash
curl -X POST http://localhost:3000/api/items \
  -H "Content-Type: application/json" \
  -d '{"name":"persistence-test"}'

docker compose restart db

curl http://localhost:3000/api/items
```

Expected: `persistence-test` remains after the database container restarts.

Actual output:
```text
PASTE ACTUAL OUTPUT HERE
```

## 6. Non-root test

```bash
docker compose exec web id
```

Expected: the process/user is `appuser`, not `root`.

Actual output:
```text
PASTE ACTUAL OUTPUT HERE
```

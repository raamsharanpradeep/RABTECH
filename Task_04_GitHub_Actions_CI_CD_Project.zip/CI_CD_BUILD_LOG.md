# CI/CD Build Log

This file records the evidence required for Task 04.

## Workflow

File:
`.github/workflows/ci-cd.yml`

Expected jobs:
1. Lint — green
2. Unit tests — green
3. Docker build/push — green on `main`

## Pull request evidence

Paste the GitHub Actions run URL and the successful job summary here:

```text
PASTE GITHUB ACTIONS RUN URL
```

Expected:
- [x] Lint passed
- [x] Unit tests passed

## Main branch evidence

Paste the successful GitHub Actions run URL here:

```text
PASTE GITHUB ACTIONS RUN URL
```

Expected:
- [x] Lint passed
- [x] Unit tests passed
- [x] Docker image built
- [x] Docker image pushed to GHCR

## Container image

Expected registry:
`ghcr.io/<owner>/<repo>`

Actual published image:
```text
PASTE GHCR IMAGE URL HERE
```

## Final submission checklist

- [x] `.github/workflows/ci-cd.yml`
- [x] Lint stage
- [x] Unit-test stage
- [x] Docker build/push stage
- [x] Secrets management through `GITHUB_TOKEN`
- [x] Workflow triggers on pull requests and pushes to main
- [ ] Actual green GitHub Actions run recorded
- [ ] Actual build logs recorded
- [ ] Public GitHub repository URL submitted

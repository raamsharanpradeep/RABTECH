# Task 04 Submission

## What is included

- `.github/workflows/ci-cd.yml`
- Automated ESLint stage
- Automated Node.js unit-test stage
- Docker multi-stage build and GHCR publish stage
- GitHub Actions badge
- `CI_CD_BUILD_LOG.md` evidence template

## Important

The workflow is ready, but GitHub must execute it before claiming a passing run. After pushing this repository:

1. Open **Actions** on GitHub.
2. Open the workflow run for a pull request and verify Lint + Unit tests are green.
3. Merge/push to `main`.
4. Verify Lint + Unit tests + Docker build/push are green.
5. Copy the public repository URL into the assignment submission field.
6. Replace the placeholder badge owner/repo in `README.md`.
7. Paste the real run URLs into `CI_CD_BUILD_LOG.md` and commit that evidence.

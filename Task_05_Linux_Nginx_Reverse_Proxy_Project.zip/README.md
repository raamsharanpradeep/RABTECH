# Linux Server Administration & Nginx Reverse Proxy

Task 05 deliverable for a secure Linux server with SSH hardening, UFW, Nginx reverse proxy, compression, caching headers, rate limiting, and TLS.

## Repository contents

- `nginx/nginx.conf` — reverse proxy and TLS configuration
- `scripts/01-ssh-hardening.sh` — key-only SSH configuration
- `scripts/02-ufw.sh` — firewall configuration
- `scripts/03-nginx-install.sh` — Nginx installation
- `scripts/04-self-signed-tls.sh` — sandbox TLS certificate
- `scripts/05-certbot.sh` — Let's Encrypt/Certbot production option
- `systemd/task05-web.service` — example hardened systemd service
- `docs/DEPLOYMENT.md` — deployment runbook
- `docs/SECURITY.md` — security decisions and controls
- `EVIDENCE_LOG.md` — commands and actual-output placeholders

## Architecture

```text
Internet
   |
   +-- :80  ---> Nginx ---> 301 HTTPS redirect
   |
   +-- :443 ---> Nginx TLS termination
                   |
                   +--> rate limit
                   +--> gzip
                   +--> cache/security headers
                   |
                   v
             127.0.0.1:3000
                Web App
```

## Important safety note

These scripts change SSH and firewall state. Run them only on a disposable/test VM or a server where you have console/recovery access. Before disabling password authentication, establish and test a working SSH-key login.

## Expected final state

- Password SSH authentication disabled
- Root SSH login disabled
- UFW permits only 22/80/443 inbound
- Nginx listens on 80/443
- Application remains private on localhost:3000
- HTTP redirects to HTTPS
- TLS 1.2/1.3 enabled
- gzip enabled
- rate limiting enabled
- security/cache headers configured

For public production use, replace the self-signed certificate with Let's Encrypt via Certbot and use a real DNS name.

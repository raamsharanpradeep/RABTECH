# Deployment Runbook

## 1. Create an administrative application user

```bash
sudo adduser --disabled-password --gecos "" deploy
sudo usermod -aG sudo deploy
```

Copy an authorized public key into `/home/deploy/.ssh/authorized_keys` and set ownership/permissions.

## 2. SSH hardening

Run:

```bash
sudo ADMIN_USER=deploy ./scripts/01-ssh-hardening.sh
```

Verify key-based login from a second terminal before closing the current SSH session.

## 3. Firewall

```bash
sudo ./scripts/02-ufw.sh
```

Verify:

```bash
sudo ufw status verbose
```

## 4. Install Nginx

```bash
sudo ./scripts/03-nginx-install.sh
```

Review `nginx/nginx.conf`, replace `example.com`, and copy it to `/etc/nginx/nginx.conf`.

## 5. TLS

Sandbox/self-signed:

```bash
sudo DOMAIN=example.com ./scripts/04-self-signed-tls.sh
```

Public production:

```bash
sudo DOMAIN=example.com EMAIL=admin@example.com ./scripts/05-certbot.sh
```

## 6. Validate Nginx

```bash
sudo nginx -t
sudo systemctl reload nginx
curl -I https://example.com
```

For a self-signed certificate, testing may require:

```bash
curl -k -I https://example.com
```

## 7. Evidence

Capture:
- `sshd -t` success
- `ufw status verbose`
- `nginx -t`
- `systemctl status nginx`
- HTTPS response headers
- successful HTTP→HTTPS redirect
- application health through `/health`

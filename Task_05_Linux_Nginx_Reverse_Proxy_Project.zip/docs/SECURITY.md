# Linux & Nginx Security Configuration

## SSH
- Dedicated `deploy` user is used instead of routine root login.
- Public-key authentication is enabled.
- Password-based and keyboard-interactive authentication are disabled.
- Root SSH login is disabled.
- `MaxAuthTries` is reduced to 3.
- SSH configuration is validated with `sshd -t` before reload.

**Operational warning:** keep an existing SSH session open and test a second key-based session before closing the original session.

## Firewall
UFW uses default-deny inbound policy and allows only:
- TCP 22 — SSH
- TCP 80 — HTTP
- TCP 443 — HTTPS

All outbound traffic is allowed by default for this exercise.

## Nginx
- TLS 1.2/1.3 only.
- `server_tokens off`.
- Security response headers.
- Gzip compression.
- Conservative per-IP rate limiting.
- Reverse proxy to the application on localhost:3000.
- HTTP redirects to HTTPS.
- Proxy timeouts prevent indefinitely hung upstream requests.

## TLS
For a sandbox, `04-self-signed-tls.sh` generates a certificate.
For a public hostname, use `05-certbot.sh` with a real DNS name and reachable ports 80/443.

## Secrets
Do not commit private keys, passwords, or `.env` files. Use a secret manager or protected environment configuration in production.

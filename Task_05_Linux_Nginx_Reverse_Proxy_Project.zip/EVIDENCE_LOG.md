# Task 05 Evidence Log

The commands below should be executed on the Linux VM/server. Replace each placeholder with the real output or a screenshot in the GitHub repository.

## 1. SSH configuration

Command:

```bash
sudo sshd -t
```

Actual result:

```text
PASTE ACTUAL OUTPUT / SCREENSHOT REFERENCE
```

Expected: no output and exit code 0.

## 2. Firewall

```bash
sudo ufw status verbose
```

Actual:

```text
PASTE ACTUAL OUTPUT / SCREENSHOT REFERENCE
```

Expected inbound rules: 22/tcp, 80/tcp, 443/tcp only.

## 3. Nginx syntax

```bash
sudo nginx -t
```

Actual:

```text
PASTE ACTUAL OUTPUT / SCREENSHOT REFERENCE
```

Expected: syntax is OK; test is successful.

## 4. Nginx service

```bash
sudo systemctl --no-pager status nginx
```

Actual:

```text
PASTE ACTUAL OUTPUT / SCREENSHOT REFERENCE
```

## 5. HTTP redirect

```bash
curl -I http://example.com
```

Expected: `301`/`308` redirect to HTTPS.

Actual:

```text
PASTE ACTUAL OUTPUT
```

## 6. HTTPS

```bash
curl -k -I https://example.com
```

Actual:

```text
PASTE ACTUAL OUTPUT
```

Expected: successful HTTPS response plus configured security headers.

## 7. Rate limiting / reverse proxy

```bash
curl -k https://example.com/health
```

Actual:

```text
PASTE ACTUAL OUTPUT
```

## 8. TLS certificate

```bash
openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -subject -issuer -dates
```

Actual:

```text
PASTE ACTUAL OUTPUT
```

## Submission

Public GitHub repository URL:

```text
PASTE PUBLIC GITHUB URL
```

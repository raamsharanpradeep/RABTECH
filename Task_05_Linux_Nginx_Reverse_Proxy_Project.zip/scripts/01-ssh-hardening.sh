#!/usr/bin/env bash
set -euo pipefail

# Run as root on a test/production Linux server.
# Before disabling password authentication, verify that an SSH-key session
# works in a second terminal.

ADMIN_USER="${ADMIN_USER:-deploy}"

id "$ADMIN_USER" >/dev/null 2>&1 || {
  echo "User $ADMIN_USER does not exist. Create it first."
  exit 1
}

install -d -m 700 -o "$ADMIN_USER" -g "$ADMIN_USER" "/home/$ADMIN_USER/.ssh"

# SSH hardening drop-in. Ubuntu/Debian use sshd_config.d.
cat >/etc/ssh/sshd_config.d/99-task05-hardening.conf <<'EOF'
PubkeyAuthentication yes
PasswordAuthentication no
KbdInteractiveAuthentication no
PermitEmptyPasswords no
PermitRootLogin no
X11Forwarding no
AllowAgentForwarding no
MaxAuthTries 3
EOF

sshd -t
systemctl reload ssh

echo "SSH hardening applied. Verify an existing key-based session before closing your current session."

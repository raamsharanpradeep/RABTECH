#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${DOMAIN:?Set DOMAIN, e.g. DOMAIN=example.com}"
EMAIL="${EMAIL:?Set EMAIL for certificate renewal notices}"

apt-get update
apt-get install -y certbot python3-certbot-nginx

certbot --nginx \
  --non-interactive \
  --agree-tos \
  --redirect \
  --hsts \
  --staple-ocsp \
  -m "$EMAIL" \
  -d "$DOMAIN"

certbot renew --dry-run

#!/usr/bin/env bash
set -euo pipefail

# WARNING: Run from an existing SSH session and confirm port 22 is allowed
# before enabling UFW, or you can lock yourself out.

ufw --force reset
ufw default deny incoming
ufw default allow outgoing

ufw allow 22/tcp comment 'SSH'
ufw allow 80/tcp comment 'HTTP'
ufw allow 443/tcp comment 'HTTPS'

ufw --force enable
ufw status verbose

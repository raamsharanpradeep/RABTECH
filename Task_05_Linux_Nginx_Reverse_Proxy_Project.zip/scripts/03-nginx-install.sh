#!/usr/bin/env bash
set -euo pipefail

apt-get update
apt-get install -y nginx

install -d -m 755 /etc/nginx/conf.d

# Copy the repository nginx configuration manually after reviewing
# server_name and certificate paths:
# cp nginx/nginx.conf /etc/nginx/nginx.conf

nginx -t
systemctl enable nginx
systemctl restart nginx
systemctl --no-pager status nginx

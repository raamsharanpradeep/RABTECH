#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${DOMAIN:-example.com}"
CERT_DIR="/etc/nginx/tls"

install -d -m 700 "$CERT_DIR"

openssl req -x509 -nodes -newkey rsa:2048 \
  -keyout "$CERT_DIR/$DOMAIN.key" \
  -out "$CERT_DIR/$DOMAIN.crt" \
  -days 365 \
  -subj "/CN=$DOMAIN" \
  -addext "subjectAltName=DNS:$DOMAIN"

chmod 600 "$CERT_DIR/$DOMAIN.key"
chmod 644 "$CERT_DIR/$DOMAIN.crt"

echo "Self-signed certificate created at $CERT_DIR."
echo "For public production traffic, prefer Let's Encrypt/Certbot instead."
